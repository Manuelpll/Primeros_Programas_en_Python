create
    definer = root@localhost procedure subida()
begin
	UPDATE EMP SET SALARIO = SALARIO + 100 WHERE DEPT_NO = 30;
 
END;

