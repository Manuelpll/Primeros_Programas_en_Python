create
    definer = Mparr@localhost function sumar(n1 int, n2 int) returns int deterministic
BEGIN
RETURN n1+n2;
END;

